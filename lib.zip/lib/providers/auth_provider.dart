import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:hive_flutter/hive_flutter.dart';
import '../services/storage.dart';

class AuthProvider with ChangeNotifier {
  final SecureStorageService _storage = SecureStorageService();

  bool _isLoggedIn = false;
  String? _accessToken;
  String? _username;
  Map<String, List<dynamic>> dropdownData = {};

  bool get isLoggedIn => _isLoggedIn;
  String? get accessToken => _accessToken;
  String? get username => _username;

  Future<bool> _hasNetworkConnection() async {
    final connectivityResult = await Connectivity().checkConnectivity();
    return connectivityResult != ConnectivityResult.none;
  }

  Future<bool> login(BuildContext context, String username, String password) async {
    int retries = 3;
    const Duration delayBetweenRetries = Duration(seconds: 2);
    const Duration timeoutDuration = Duration(seconds: 10);

    if (!await _hasNetworkConnection()) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('No internet connection. Please try again.')),
      );
      return false;
    }

    while (retries > 0) {
      try {
        final response = await http
            .post(
              Uri.parse('https://incident.com.et/api/token/'),
              headers: {'Content-Type': 'application/x-www-form-urlencoded'},
              body: {'username': username, 'password': password},
            )
            .timeout(timeoutDuration);

        if (response.statusCode == 200) {
          final data = json.decode(response.body);
          if (data.containsKey('access')) {
            _accessToken = data['access'];
            await _storage.saveData('access_token', _accessToken!);
            await _storage.saveData('username', username);

            _isLoggedIn = true;
            notifyListeners();
            return true;
          } else {
            print('Unexpected response: ${response.body}');
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Unexpected server response. Please try again.')),
            );
            return false;
          }
        } else if (response.statusCode == 401) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Invalid credentials. Please try again.')),
          );
          return false;
        } else if (response.statusCode >= 500) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Server error. Please try again later.')),
          );
          return false;
        }
      } catch (e) {
        print('Login attempt failed: $e');
        retries--;
        if (retries == 0) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Failed to login after multiple attempts: $e')),
          );
          return false;
        }
        await Future.delayed(delayBetweenRetries * (3 - retries));
      }
    }
    return false;
  }



  Future<void> fetchDropdownData() async {
    if (_accessToken == null) {
      print("Access token not found. Cannot fetch dropdown data.");
      return;
    }

    final url = 'https://incident.com.et/api/dropdown-data/';
    try {
      final response = await http
          .get(
            Uri.parse(url),
            headers: {
              'Authorization': 'Bearer $_accessToken',
            },
          )
          .timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final parsedData = json.decode(response.body) as Map<String, dynamic>;
        dropdownData = parsedData.map((key, value) => MapEntry(key, value as List<dynamic>));
        print("Dropdown data fetched successfully.");
        notifyListeners();
      } else {
        print("Failed to fetch dropdown data: ${response.statusCode}");
      }
    } catch (e) {
      print("Error fetching dropdown data: $e");
    }
  }

  Future<void> submitForm(Map<String, dynamic> formData) async {
    const Duration timeoutDuration = Duration(seconds: 10);

    if (!await _hasNetworkConnection()) {
      print("No network connection. Caching form data locally.");
      await _cacheFormLocally(formData);
      return;
    }

    try {
      final response = await http
          .post(
            Uri.parse('https://incident.com.et/api/forms/submit/'),
            headers: {
              'Authorization': 'Bearer $_accessToken',
              'Content-Type': 'application/json',
            },
            body: json.encode(formData),
          )
          .timeout(timeoutDuration);

      if (response.statusCode == 201) {
        print("Form submitted successfully.");
      } else {
        print("Server error. Caching form data locally.");
        await _cacheFormLocally(formData);
      }
    } catch (e) {
      print("Error submitting form: $e. Caching form data locally.");
      await _cacheFormLocally(formData);
    }
  }

  Future<void> _cacheFormLocally(Map<String, dynamic> formData) async {
    final box = await Hive.openBox('form_cache');
    await box.add(formData);
    print("Form data cached locally.");
  }

  Future<void> syncCachedForms() async {
    if (!await _hasNetworkConnection()) {
      print("No network connection. Cannot sync cached forms.");
      return;
    }

    final box = await Hive.openBox('form_cache');
    final cachedForms = box.values.toList();

    for (var formData in cachedForms) {
      try {
        final response = await http
            .post(
              Uri.parse('https://incident.com.et/api/forms/submit/'),
              headers: {
                'Authorization': 'Bearer $_accessToken',
                'Content-Type': 'application/json',
              },
              body: json.encode(formData),
            )
            .timeout(Duration(seconds: 10));

        if (response.statusCode == 201) {
          print("Cached form submitted successfully.");
          await box.deleteAt(cachedForms.indexOf(formData));
        } else {
          print("Failed to submit cached form: ${response.statusCode}");
        }
      } catch (e) {
        print("Error syncing cached form: $e");
      }
    }
  }

  Future<void> logout() async {
    _isLoggedIn = false;
    _accessToken = null;
    await _storage.clearData();
    notifyListeners(); // Notify the UI about the change
  }

  Future<void> loadUser() async {
    print("Loading user session...");
    _accessToken = await _storage.readData('access_token');
    _username = await _storage.readData('username');

    _isLoggedIn = _accessToken != null;
    notifyListeners();

    if (_isLoggedIn) {
      print("User session restored. User: $_username");
      // Fetch dropdown data to refresh session context
      await fetchDropdownData();
    } else {
      print("No user session found.");
    }
  }
}
